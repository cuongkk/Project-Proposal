#ifndef BILL_H
#define BILL_H

#include "Customer.h"
#include "Cart.h"

#include <iostream>
#include <string>

class Bill
{
protected:
    std::string _id_Bill;
    std::string _id_Customer;
    Cart _cart;
    float _totalCost;

public:
    Bill();
    ~Bill();

    Bill(const std::string &, Cart &&);
    float get_totalCost() const;

    friend std::ostream &operator<<(std::ostream &, const Bill &);
};
#endif
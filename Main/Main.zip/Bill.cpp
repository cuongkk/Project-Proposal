#include "Bill.h"

Bill::Bill()
{
    _id_Bill = "";
    _id_Customer = "";
    _totalCost = 0.0f;
}

Bill::~Bill() = default;

Bill::Bill(const std::string &id_Customer, Cart &&cart)
{
    _id_Customer = id_Customer;
    _cart = std::move(cart);
    _totalCost = _cart.get_cost();
}

float Bill::get_totalCost() const
{
    return _totalCost;
}

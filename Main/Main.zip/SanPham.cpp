#include "SanPham.h"
#include "ThucAn.h"
SanPham::SanPham()
{
    _id = "";
    _type = "";
    _quantity = 0;
    _cost = 0;
    _discount = 0;
    _manufacture_Date = "";
    _expiry_Date = "";
}

SanPham::SanPham(const std::string &type, const int &quantity, const float &cost, const float &discount,
                 const std::string &manufacture_Date, const std::string &expiry_Date)
{
    _id = set_id("SP", _id_counter_sp);
    _type = type;
    _quantity = quantity;
    _cost = cost;
    _discount = discount;
    _manufacture_Date = manufacture_Date;
    _expiry_Date = expiry_Date;
}

void SanPham::set_counter(const int &index)
{
    _id_counter_sp[index] = 0;
}

std::string SanPham::get_id() const
{
    return _id;
}

void SanPham::set_quantity(int quantity)
{
    _quantity = quantity;
}

int SanPham::get_quantity() const
{
    return _quantity;
}

void SanPham::set_cost(int cost)
{
    _cost = cost;
}

float SanPham::get_cost() const
{
    return _cost;
}

void SanPham::set_discount(int discount)
{
    _discount = discount;
}

float SanPham::get_discount() const
{
    return _discount;
}

float operator+(const float &a, const SanPham &b)
{
    return a + b.get_quantity() * b.get_cost() * (1 - b.get_discount());
}
std::unique_ptr<SanPham> operator+(const SanPham &a, const SanPham &b)
{
    auto res = std::make_unique<ThucAn>();
    res->set_cost(a.get_quantity() * a.get_cost() * (1 - a.get_discount()) + b.get_quantity() * b.get_cost() * (1 - b.get_discount()));
    return res;
}

std::unique_ptr<SanPham> operator+(std::unique_ptr<SanPham> a, const SanPham &b)
{
    auto res = std::make_unique<ThucAn>();
    res->set_cost(a->get_quantity() * a->get_cost() * (1 - a->get_discount()) + b.get_quantity() * b.get_cost() * (1 - b.get_discount()));
    return res;
}

std::unique_ptr<SanPham> operator-(const SanPham &a, const SanPham &b)
{
    auto res = std::make_unique<ThucAn>();
    res->set_cost(a.get_quantity() * a.get_cost() * (1 - a.get_discount()) - b.get_quantity() * a.get_cost() * (1 - b.get_discount()));
    return res;
}

std::unique_ptr<SanPham> operator-(std::unique_ptr<SanPham> a, const SanPham &b)
{
    auto res = std::make_unique<ThucAn>();
    res->set_cost(a->get_quantity() * a->get_cost() * (1 - a->get_discount()) - b.get_quantity() * b.get_cost() * (1 - b.get_discount()));
    return res;
}

bool operator==(const SanPham &a, const SanPham &b)
{
    return a.get_id() == b.get_id();
}
std::ostream &operator<<(std::ostream &os, const SanPham &sp)
{
    sp.print(os);
    return os;
}
#ifndef CART_H
#define CART_H

#include "KhoHang.h"
#include "SanPham.h"
#include "LinkedList.h"
class Cart
{
protected:
    std::string _id_Customer;

public:
    Cart();
    ~Cart();
    Cart(const std::string &);
    LinkedList<SanPham> _sanpham;

    int get_size() const;
    float get_cost() const;

    bool add(KhoHang &, std::unique_ptr<SanPham>);
    void remove(KhoHang &, std::unique_ptr<SanPham>);

    void operator=(const Cart &);
    friend std::ostream &operator<<(std::ostream &os, const Cart &);
};
#endif
#include "Main_all.h"

std::vector<int> User::_id_counter_user = {0};

std::vector<int> Bill::_id_counter_bill = {0};

std::vector<int> SanPham::_id_counter_sp = {0};